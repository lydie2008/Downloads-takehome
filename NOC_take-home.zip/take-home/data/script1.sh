#!/bin/bash

DIRECTORY1="/tmp/dir1"
DIRECTORY2="/tmp/dir2"
RESULT="null"

FILECONTENTS=$(cat <<EOF
Lorem ipsum dolor sit amet, consectetur |adipiscing elit, sed do eiusmod tempor
|incididunt ut labore et dolore magna aliqua. |Ut enim ad minim veniam, quis nostrud
|exercitation ullamco laboris nisi ut aliquip |ex ea commodo consequat.
EOF
)

PRECHECK()
{

    #PART 1
    if [ "$(whoami)" != "root" ]
    then
        echo -e "You need to run the script as root\n"
        exit 1
    fi

    #PART 2
    for i in $DIRECTORY1 $DIRECTORY2; do 
        if [ ! -d $i ]
        then
            echo -e "Required directory ${i} does not exist..yet"
            mkdir $i
        else
            echo -e "Required directory ${i} exists"
        fi
    done

}

EVENODD()
{
    NUMBER=$1
    if [ $((NUMBER%2)) -eq 0 ]
    then
        RESULT='even'
    else
        RESULT='odd'
    fi
}

MAIN()
{
    #PART 1
    echo $FILECONTENTS | tr '|' '\n' > $DIRECTORY1/file1
    local status=$?
    if [ $status -ne 0 ]
    then
        echo "Unable to create/populate ${DIRECTORY1}/file1"
        exit 1
    fi
    
    #PART 2
    COUNT=2
    while read -r line;
    do  
        echo "Creating file${COUNT} in ${DIRECTORY1}"
        echo $line > $DIRECTORY1/file$COUNT;
        let COUNT=COUNT+1
    done < $DIRECTORY1/file1

    #PART 4
    for i in `ls $DIRECTORY1`;
    do
        echo "Archiving ${i} to ${DIRECTORY2}"
        cp $DIRECTORY1/$i $DIRECTORY2/$i.bak
        local status=$?
        if [ $status -ne 0 ]
        then
            echo "Unable to archive ${DIRECTORY1}/${i}"
        fi
    done

    echo -e "\nContents of Archive:"
    echo `ls ${DIRECTORY2}`

    #PART 5
    echo -e "\nNumbers Game"
    for i in `ls $DIRECTORY1/`;
    do
        local NUMBER=`echo $i | sed 's/[a-z]//g'`
        EVENODD $NUMBER
        if [[ $RESULT == "even" ]];
        then
            echo "${i} has an ${RESULT} number in its name, deleting"
            rm -f $DIRECTORY1/$i
        fi
    done

}

PRECHECK
MAIN
exit 0